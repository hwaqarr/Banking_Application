To run the program ensure that the json-simple file is linked in the referenced libraries

Then simply run the driver class.